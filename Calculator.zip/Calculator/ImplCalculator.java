//implementing the Remote Interface

public class ImplCalculator implements Calculator{
	//implementing the interface methods
	public int add(int a,int b){
		return a+b;
	}
	public int sub(int a,int b){
		return a-b;
	}
	public int mul(int a,int b){
		return a*b;
	}
	public int div(int a,int b){
		return a/b;
	}
	public int mod(int a,int b){
		return a%b;
	}
}
