import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.io.*;

public class Client{
	private Client(){}
	public static void main(String[] args){
		try{
			//Getting the registry
			Registry registry=LocateRegistry.getRegistry(null);
			//Looking up the registry for the remote object
			TellTheTime ttt=(TellTheTime)registry.lookup("TellTheTime");
			//Calling the remote method using the obtained object
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter the time in the format (hh:mm) : ");
			String str="";
			while(!(str=br.readLine()).equals("exit")){
				System.out.println(ttt.tellTheTime(str));
				System.out.print("Enter the time in the format (hh:mm) : ");
			}
		}catch(Exception e){
			System.err.println("Client exception:"+e.toString());
			e.printStackTrace();
		}
	}
}
