import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Server extends ImplTellTheTime{
	public Server(){}
	public static void main(String[] args){
		try{
			//Instantiating the implementation class
			ImplTellTheTime obj=new ImplTellTheTime();
			//Exporting the object of implementation class
			TellTheTime stub=(TellTheTime)UnicastRemoteObject.exportObject(obj,0);
			//Binding the remote object in the registry
			Registry registry=LocateRegistry.getRegistry();
			registry.bind("TellTheTime",stub);
			System.out.println("Server ready");
		}catch(Exception e){
			System.err.println("Server exception:"+e.toString());
			e.printStackTrace();
		}
	}
}
