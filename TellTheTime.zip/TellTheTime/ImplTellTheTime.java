//implementing the Remote Interface
import java.util.*;

public class ImplTellTheTime implements TellTheTime{
	//implementing the interface methods
	public String tellTheTime(String str){
		StringTokenizer st=new StringTokenizer(str,":");
		int hh=Integer.parseInt(st.nextToken());
		int mm=Integer.parseInt(st.nextToken());
		String time_phrase="";
		if(hh>=24){
		    return "Invalid time input";
		}
		else if(hh>=5 && hh<12){
		    time_phrase="in the morning";
		}
		else if(hh>=12 && hh<15){
		    time_phrase="in the early afternoon";
		}
		else if(hh>=15 && hh<17){
		    time_phrase="in the late afternoon";
		}
		else if(hh>=17 && hh<=21){
		    time_phrase="in the evening";
		}
		else{
		    time_phrase="at night";
		}
		if(mm==0){
		    if(hh==12){
		        return "It's noon.";
		    }
		    else if(hh==0){
		        return "It's midnight.";
		    }
		    if(hh>12)
		        return "It's "+(hh-12)+" "+time_phrase;
		    else
		        return "It's "+hh+" "+time_phrase;
		}
		else{
		    String mm_str="";
		    if(mm==15){
		        mm_str="quarter";
		    }
		    else if(mm==30){
		        mm_str="half";
		    }
		    else{
		        mm_str=mm+"";
		    }
		    if(hh>12)
		        return "It's "+mm_str+" after "+(hh-12)+" "+time_phrase;
		    else
		        return "It's "+mm_str+" after "+hh+" "+time_phrase;
		}
     	}
}
