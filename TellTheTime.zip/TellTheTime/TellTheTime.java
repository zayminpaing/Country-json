import java.rmi.Remote;
import java.rmi.RemoteException;

//Creating Remote Interface for out application
public interface TellTheTime extends Remote{
	String tellTheTime(String str) throws RemoteException;
}
