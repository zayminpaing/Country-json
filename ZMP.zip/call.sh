#! /bin/bash
/home/pi/Desktop/ZMP/HDB/AGGREGATE_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/ASC_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/AWBA_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/EVO_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/MAI_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/MKTK_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/MSCN_LIVE/backup.sh
/home/pi/Desktop/ZMP/HDB/PAHTAMA/backup.sh
/home/pi/Desktop/ZMP/HDB/PITI_PYAE_ZONE_COMPANY/backup.sh
/home/pi/Desktop/ZMP/HDB/UAT_AWBA/backup.sh
