#! /bin/bash
PREFIX="bck_"
DATE="$PREFIX$(date +%Y%m%d)"
FILE="$(ls | grep $DATE)"
if [ "$DATE"* = "$FILE" ]; then
    cp -r "$FILE" /home/pi/Desktop/HDB_HUAWEI/
    echo Success:   MKTK_LIVE,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo "Found"
else
    echo Failed:    MKTK_LIVE,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo "Not Found"
fi

