#! /bin/bash
PREFIX="bck_"
DATE="$PREFIX$(date +%Y%m%d)"
FILE="$(ls | grep $DATE)"
if [ "$DATE"* = "$FILE" ]; then
    cp -r "$FILE" /home/pi/Desktop/ZMP/HDB_HUAWEI/
    echo Success,PAHTAMA,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Success,PAHTAMA,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_success.txt
    echo "Found"
else
    echo Failed,PAHTAMA,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Failed,PAHTAMA,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_failed.txt
    echo "Not Found"
fi

