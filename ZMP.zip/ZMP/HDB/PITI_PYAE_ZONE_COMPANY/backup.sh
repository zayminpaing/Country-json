#! /bin/bash
PREFIX="bck_"
DATE="$PREFIX$(date +%Y%m%d)"
FILE="$(ls | grep $DATE)"
if [ "$DATE"* = "$FILE" ]; then
    cp -r "$FILE" /home/pi/Desktop/ZMP/HDB_HUAWEI/
    echo Success,PITI_PYAE_ZONE_COMPANY,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Success,PITI_PYAE_ZONE_COMPANY,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_success.txt
    echo "Found"
else
    echo Failed,PITI_PYAE_ZONE_COMPANY,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Failed,PITI_PYAE_ZONE_COMPANY,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_failed.txt
    echo "Not Found"
fi

