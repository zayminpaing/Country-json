#! /bin/bash
PREFIX="bck_"
DATE="$PREFIX$(date +%Y%m%d)"
FILE="$(ls | grep $DATE)"
if [ "$DATE"* = "$FILE" ]; then
    cp -r "$FILE" /home/pi/Desktop/HDB_HUAWEI/
    echo Success,AWBA_LIVE,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Success,AWBA_LIVE,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_success.txt
    echo "Found"
else
    echo Failed,AWBA_LIVE,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Failed,AWBA_LIVE,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_failed.txt
    echo "Not Found"
fi

