#! /bin/bash
PREFIX="bck_"
DATE="$PREFIX$(date +%Y%m%d)"
FILE="$(ls | grep $DATE)"
if [ "$DATE"* = "$FILE" ]; then
    cp -r "$FILE" /home/pi/Desktop/HDB_HUAWEI/
    echo Success,ASC_LIVE,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Success,ASC_LIVE,$(date),$(ls -l --block-size=MB "$FILE" | grep "total") >> /home/pi/Desktop/ZMP/HDB/temp_success.txt
    echo "Found"
else
    echo Failed,ASC_LIVE,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_log.txt
    echo Failed,ASC_LIVE,$(date) >> /home/pi/Desktop/ZMP/HDB/temp_failed.txt
    echo "Not Found"
fi

